class Lootinfo:
	def __init__(self, fir_status, quest1, quest2, hideout, mycount):
		self.fir_status = fir_status
		self.quest1 = quest1
		self.quest2 = quest2
		self.hideout = hideout
		self.mycount = mycount
